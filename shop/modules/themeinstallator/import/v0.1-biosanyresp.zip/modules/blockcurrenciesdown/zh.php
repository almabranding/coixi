<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcurrenciesdown}prestashop>blockcurrenciesdown_1563670e90b626bbd1f426318398630b'] = '货币块下拉';
$_MODULE['<{blockcurrenciesdown}prestashop>blockcurrenciesdown_2f6a7642f59ee9a7639db82a5d538510'] = '增加了对货币的选择�';
