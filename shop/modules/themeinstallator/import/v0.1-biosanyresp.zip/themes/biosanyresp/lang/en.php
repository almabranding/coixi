<?php

global $_LANG;
$_LANG = array();
$_LANG['footer_2ae41fa6dbd644a6846389ad14167167'] = '2013 © Biosany Responsive';
$_LANG['footer_34c869c542dee932ef8cd96d2f91cae6'] = 'Stores';

?>