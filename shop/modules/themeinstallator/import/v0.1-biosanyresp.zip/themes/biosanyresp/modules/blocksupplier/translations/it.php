<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksupplier}biosanyresp>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Fornitori';
$_MODULE['<{blocksupplier}biosanyresp>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'Maggiori informazioni su';
$_MODULE['<{blocksupplier}biosanyresp>blocksupplier_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'Tutti i fornitori';
$_MODULE['<{blocksupplier}biosanyresp>blocksupplier_496689fbd342f80d30f1f266d060415a'] = 'Nessun fornitore';

