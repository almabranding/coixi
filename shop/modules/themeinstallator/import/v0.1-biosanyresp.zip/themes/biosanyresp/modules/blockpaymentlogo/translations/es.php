<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_1bd130f5640104712b3c7dec66b7b0a1'] = 'Bloque de logos de pago';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_8e27bf58ec687eea4b244d563dcbd8ac'] = 'Añadir un bloque para mostrar todos los logos de modos de pago';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_8fc87743f34723d06ebff41629d2fdb5'] = 'Logos de pago';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_7ccf58c950043c9fbfed668df13ce608'] = 'Parámetros actualizados';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_d16dbbe71a327e22461456cfc5e7dfb2'] = 'Página CMS no disponible';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_f1206f9fadc5ce41694f69129aecac26'] = 'Configure';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_4b3c34d991275b9fdb0facfcea561be9'] = 'Página CMS para enlaces';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_01bb71b3e70e9e5057c9678a903d47ac'] = 'Seleccionar una página';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_d4dccb8ca2dac4e53c01bd9954755332'] = 'Guardar los parámetros';



