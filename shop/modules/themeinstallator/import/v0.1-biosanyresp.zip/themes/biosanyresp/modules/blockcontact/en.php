<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}calceus>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Contact us';
$_MODULE['<{blockcontact}calceus>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Phone :';
$_MODULE['<{blockcontact}calceus>blockcontact_8b1f7be76996ad6911a17592b9804e1b'] = 'Our hotline is available 24 hours / 7';
$_MODULE['<{blockcontact}calceus>blockcontact_e6d0e56415c30a59658fb34ef5d7be35'] = 'Our hotline';
