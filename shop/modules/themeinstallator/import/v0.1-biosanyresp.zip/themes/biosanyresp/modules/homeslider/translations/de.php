<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homeslider}biosanyresp>homeslider_e933dc24fb245d863a43b4fefe9b45f5'] = 'Höhe:';
$_MODULE['<{homeslider}biosanyresp>homeslider_48ccf48dcf2218a413ce473262f21a0c'] = 'Breite:';
$_MODULE['<{homeslider}biosanyresp>homeslider_154e6bcf4e3b49a424323cb9021ef851'] = 'Pause';
$_MODULE['<{homeslider}biosanyresp>homeslider_93cba07454f06a4a960172bbd6e2a435'] = 'Ja';
$_MODULE['<{homeslider}biosanyresp>homeslider_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nein';
$_MODULE['<{homeslider}biosanyresp>homeslider_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{homeslider}biosanyresp>homeslider_7dce122004969d56ae2e0245cb754d35'] = 'Bearbeiten';
$_MODULE['<{homeslider}biosanyresp>homeslider_f2a6c498fb90ee345d997f888fce3b18'] = 'Löschen';
$_MODULE['<{homeslider}biosanyresp>homeslider_a5220b3d801e803e8c4133edcd0dc7b4'] = 'Wählen Sie eine Datei';
$_MODULE['<{homeslider}biosanyresp>homeslider_51ec9bf4aaeab1b25bb57f9f8d4de557'] = 'Name:';
$_MODULE['<{homeslider}biosanyresp>homeslider_3b3d06023f6353f8fd05f859b298573e'] = 'URL:';
$_MODULE['<{homeslider}biosanyresp>homeslider_8046c95f98fc714db47978092bb24264'] = 'Legende';
$_MODULE['<{homeslider}biosanyresp>homeslider_d0042a700e9bdf79689d63ee6846dc0e'] = 'Beschreibung:';
$_MODULE['<{homeslider}biosanyresp>homeslider_3d091e856cb7615d1ccb96bc759b5a92'] = 'Aktiv';
$_MODULE['<{homeslider}biosanyresp>homeslider_ea4788705e6873b424c65e91c2846b19'] = 'Abbrechen';
$_MODULE['<{homeslider}biosanyresp>homeslider_70397c4b252a5168c5ec003931cea215'] = 'Pflichtfelder';
$_MODULE['<{homeslider}biosanyresp>homeslider_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguration aktualisiert';
$_MODULE['<{homeslider}biosanyresp>homeslider_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Ein Fehler trat beim Hochladen des Bilds auf.';
$_MODULE['<{homeslider}biosanyresp>homeslider_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{homeslider}biosanyresp>homeslider_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';



