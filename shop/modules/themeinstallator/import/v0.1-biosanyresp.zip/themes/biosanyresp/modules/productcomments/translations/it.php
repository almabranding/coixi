<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_7c3b0e9898b88deee7ea75aafd2e37e2'] = 'Grado medio';
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_a71a0229e164fecdcde3c4e0f40473fa'] = 'Leggi interviste clienti';
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_7966126831926ad29c528b239d69f855'] = 'Scrivi la tua intervista';
$_MODULE['<{productcomments}biosanyresp>productcomments_4494d00c901c9e22ff3b953177205cea'] = 'Sei sicuro che vuoi segnalare questo commento?';
$_MODULE['<{productcomments}biosanyresp>productcomments_4b3b9db8c9784468094acde0f8bf7071'] = 'Voto';
$_MODULE['<{productcomments}biosanyresp>productcomments_b5c82723bd85856358f9a376bc613998'] = '%1$d jsu %2$d clienti trovano questa intervista utile';
$_MODULE['<{productcomments}biosanyresp>productcomments_39630ad6ee79b8653ea89194cdb45bec'] = 'Trovi questo commento utile per te?';
$_MODULE['<{productcomments}biosanyresp>productcomments_a6105c0a611b41b08f1209506350279e'] = 'sì';
$_MODULE['<{productcomments}biosanyresp>productcomments_7fa3b767c460b54a2be4d49030b349c7'] = 'no';
$_MODULE['<{productcomments}biosanyresp>productcomments_28b3b1e564a00f572c5d4e21da986d49'] = 'Segnala abuso';
$_MODULE['<{productcomments}biosanyresp>productcomments_fbe2625bf3673be380d043a4bf873f28'] = 'Sii il primo a scrivere una intervista su questo prodotto';
$_MODULE['<{productcomments}biosanyresp>productcomments_08621d00a3a801b9159a11b8bbd69f89'] = 'Non ci sono commenti dei clienti per il momento.';
$_MODULE['<{productcomments}biosanyresp>productcomments_7966126831926ad29c528b239d69f855'] = 'Scrivi la tua intervista';
$_MODULE['<{productcomments}biosanyresp>productcomments_b78a3223503896721cca1303f776159b'] = 'Titolo';
$_MODULE['<{productcomments}biosanyresp>productcomments_0be8406951cdfda82f00f79328cf4efc'] = 'Commenta';
$_MODULE['<{productcomments}biosanyresp>productcomments_221e705c06e231636fdbccfdd14f4d5c'] = 'Il tuo nome:';
$_MODULE['<{productcomments}biosanyresp>productcomments_70397c4b252a5168c5ec003931cea215'] = 'Campi richiesti';
$_MODULE['<{productcomments}biosanyresp>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = 'Invia';
$_MODULE['<{productcomments}biosanyresp>productcomments_ea4788705e6873b424c65e91c2846b19'] = 'Annulla';
$_MODULE['<{productcomments}biosanyresp>products-comparison_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Commenti';
$_MODULE['<{productcomments}biosanyresp>products-comparison_b1897515d548a960afe49ecf66a29021'] = 'Media';
$_MODULE['<{productcomments}biosanyresp>products-comparison_bc976f6c3405523cde61f63a7cbe224b'] = 'visualizzare i commenti';
$_MODULE['<{productcomments}biosanyresp>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Commenti';

