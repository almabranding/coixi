<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_e5b7525b4214a759876af4448bd6b87d'] = 'Menù orizzontale';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_925a8a825a28f69e7a96f5996f9cfcc5'] = 'Aggiunge un nuovo menù orizzontale nel Top del tuo negozio.';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_597582c140dd691b522fe42299a24d34'] = 'Impostazioni aggiornate';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_b9129c167a73844d16d28b0949719155'] = 'Impossibile aggiornare impostazioni.';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_7710e9fcaec3369276557496da24640a'] = 'Per favore, riempi il campo “Link”';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_3679e307d4a14646c488a65381de82ea'] = 'Per favore aggiunti una etichetta.';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_b2385ac89327dbaeb21d35fa016a3e3e'] = 'Per favore aggiungi una etichetta per la lingua di defalut';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_11ad009c1b7c0615be18fe91185c179a'] = 'Il link è stato aggiunto con successo';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_15772d25000bce9fc3a2a2fd7d41a717'] = 'Il link è stao rimosso';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_d1156d9314813566c02aedc3852bdcab'] = 'Il link è stato modificato';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_242e9577826290307cd3e45a259172cc'] = 'Le modifiche saranno applicate a';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_fb9ddcf8de4f32e4db61221d5cebb108'] = 'negozio:';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_540c8f06b80b4ec911505764eb455f4d'] = 'tutti I negozi';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_9dea4016dbcc290b773ab2fae678aaa8'] = 'Articoli';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_c7da501f54544eba6787960200d9efdb'] = 'CMS';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_ec136b444eede3bc85639fac0dd06229'] = 'Fornitore';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_c0bd7654d5b278e65f21cf4e9153fdb4'] = 'Produttore';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categorie';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_068f80c7519d0528fb08e82137a72131'] = 'Prodotti';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_ac3b3f2d1984171e48eaa3d0bc56d75f'] = 'Scegli un ID prodotto';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_56e8bf6c54f1638e7bce5a2fcd5b20fe'] = 'Link Top menù';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_ec211f7c20af43e742bf2570c3cb84f9'] = 'Aggiungi';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_1063e38cb53d94d386f21227fcd84717'] = 'Elimina';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_fcd7ab4061bb3846392cc34376902165'] = 'Selezione Id prodotto';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_97f08a40f22a625d0cbfe03db3349108'] = 'ID prodotto';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_8cc149b77eaece54cee2e7e02f40018a'] = 'Casella di ricerca';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_dbd7201170abec94907af0cc1680d22d'] = 'Salva';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_9f1b01ac44ff287d5b8ed20ec8ee180b'] = 'Aggiungi un link al menù';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_b021df6aac4654c454f46c77646e745f'] = 'Etichetta';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_4994a8ffeba4ac3140beb89e8d41f174'] = 'Lingua';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_7a115fe2bd8b94ead1550a2da953cf87'] = 'Nuova finestra';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_7dce122004969d56ae2e0245cb754d35'] = 'Modifica';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_5c99ba0242e549e14a00ad361de435d1'] = 'Aggiungi';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_814579fdad9baf2cdcac456468265384'] = 'Lista I link del menù';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_4443702c8a13a65ac66d074b7a82af9a'] = 'Link id';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_004bf6c9a40003140292e97330236c53'] = 'Azione';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_93cba07454f06a4a960172bbd6e2a435'] = 'Sì';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';



