<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}biosanyresp>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Ausgewählte Produkte';
$_MODULE['<{homefeatured}biosanyresp>homefeatured_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Guthaben';
$_MODULE['<{homefeatured}biosanyresp>homefeatured_03c2e7e41ffc181a4e84080b4710e81e'] = 'Neu';
$_MODULE['<{homefeatured}biosanyresp>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Mehr';
$_MODULE['<{homefeatured}biosanyresp>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Anzeigen';
$_MODULE['<{homefeatured}biosanyresp>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'In den Warenkorb';
$_MODULE['<{homefeatured}biosanyresp>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Keine ausgewählten Produkte';

