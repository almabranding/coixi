<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}biosanyresp>blocknewproducts_60efcc704ef1456678f77eb9ee20847b'] = 'New products';


