<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_7c3b0e9898b88deee7ea75aafd2e37e2'] = 'Note moyenne';
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_a71a0229e164fecdcde3c4e0f40473fa'] = 'Lire les avis utilisateurs';
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_7966126831926ad29c528b239d69f855'] = 'Donnez votre avis';
$_MODULE['<{productcomments}biosanyresp>productcomments_4494d00c901c9e22ff3b953177205cea'] = 'Êtes-vous sur de vouloir signaler ce commentaire ?';
$_MODULE['<{productcomments}biosanyresp>productcomments_4b3b9db8c9784468094acde0f8bf7071'] = 'Note';
$_MODULE['<{productcomments}biosanyresp>productcomments_b5c82723bd85856358f9a376bc613998'] = '%1$d personne(s) sur %2$d ont trouvé ce commentaire utile.';
$_MODULE['<{productcomments}biosanyresp>productcomments_39630ad6ee79b8653ea89194cdb45bec'] = 'Ce commentaire vous a-t-il été utile ?';
$_MODULE['<{productcomments}biosanyresp>productcomments_a6105c0a611b41b08f1209506350279e'] = 'oui';
$_MODULE['<{productcomments}biosanyresp>productcomments_7fa3b767c460b54a2be4d49030b349c7'] = 'non';
$_MODULE['<{productcomments}biosanyresp>productcomments_28b3b1e564a00f572c5d4e21da986d49'] = 'Reporter un abus';
$_MODULE['<{productcomments}biosanyresp>productcomments_fbe2625bf3673be380d043a4bf873f28'] = 'Soyez le premier à donner votre avis';
$_MODULE['<{productcomments}biosanyresp>productcomments_08621d00a3a801b9159a11b8bbd69f89'] = 'Aucun commentaire n\'a été publié pour le moment.';
$_MODULE['<{productcomments}biosanyresp>productcomments_7966126831926ad29c528b239d69f855'] = 'Donner votre avis';
$_MODULE['<{productcomments}biosanyresp>productcomments_b78a3223503896721cca1303f776159b'] = 'Titre';
$_MODULE['<{productcomments}biosanyresp>productcomments_0be8406951cdfda82f00f79328cf4efc'] = 'Commentaire';
$_MODULE['<{productcomments}biosanyresp>productcomments_221e705c06e231636fdbccfdd14f4d5c'] = 'Votre nom';
$_MODULE['<{productcomments}biosanyresp>productcomments_70397c4b252a5168c5ec003931cea215'] = 'Champs requis';
$_MODULE['<{productcomments}biosanyresp>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = 'Envoyer';
$_MODULE['<{productcomments}biosanyresp>productcomments_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_MODULE['<{productcomments}biosanyresp>products-comparison_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Commentaires';
$_MODULE['<{productcomments}biosanyresp>products-comparison_b1897515d548a960afe49ecf66a29021'] = 'Moyenne';
$_MODULE['<{productcomments}biosanyresp>products-comparison_bc976f6c3405523cde61f63a7cbe224b'] = 'Voir les avis';
$_MODULE['<{productcomments}biosanyresp>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Commentaires';

