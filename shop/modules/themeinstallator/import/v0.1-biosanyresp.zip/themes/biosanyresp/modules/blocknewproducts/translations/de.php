<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}biosanyresp>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Neue Produkte';
$_MODULE['<{blocknewproducts}biosanyresp>blocknewproducts_43340e6cc4e88197d57f8d6d5ea50a46'] = 'mehr..';
$_MODULE['<{blocknewproducts}biosanyresp>blocknewproducts_60efcc704ef1456678f77eb9ee20847b'] = 'Neuen Produkte';
$_MODULE['<{blocknewproducts}biosanyresp>blocknewproducts_2bc4c1efe10bba9f03fac3c59b4d2ae9'] = 'Keine neuen Produkte zu diesem Zeitpunkt';

