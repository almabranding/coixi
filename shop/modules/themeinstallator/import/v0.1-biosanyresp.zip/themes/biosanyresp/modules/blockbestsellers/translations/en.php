<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers-home_eae99cd6a931f3553123420b16383812'] = 'Best sellers';
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Best sellers';


