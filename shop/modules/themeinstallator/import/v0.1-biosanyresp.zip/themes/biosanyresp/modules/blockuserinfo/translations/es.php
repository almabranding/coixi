<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}biosanyresp>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Bienvenido';
$_MODULE['<{blockuserinfo}biosanyresp>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Cerrer sesión';
$_MODULE['<{blockuserinfo}biosanyresp>blockuserinfo_4394c8d8e63c470de62ced3ae85de5ae'] = 'Salir';
$_MODULE['<{blockuserinfo}biosanyresp>blockuserinfo_bffe9a3c9a7e00ba00a11749e022d911'] = 'Iniciar';
$_MODULE['<{blockuserinfo}biosanyresp>blockuserinfo_12641546686fe11aaeb3b3c43a18c1b3'] = 'Su carrito de la compra';
$_MODULE['<{blockuserinfo}biosanyresp>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Su cuenta';

