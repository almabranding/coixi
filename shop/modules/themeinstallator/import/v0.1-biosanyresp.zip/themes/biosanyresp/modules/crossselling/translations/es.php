<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{crossselling}biosanyresp>crossselling_ef2b66b0b65479e08ff0cce29e19d006'] = 'Los clientes que compraron este producto también han comprado...';
$_MODULE['<{crossselling}biosanyresp>crossselling_dd1f775e443ff3b9a89270713580a51b'] = 'Anterior';
$_MODULE['<{crossselling}biosanyresp>crossselling_4351cfebe4b61d8aa5efa1d020710005'] = 'Vista';
$_MODULE['<{crossselling}biosanyresp>crossselling_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Siguiente';

