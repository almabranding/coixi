<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_7c3b0e9898b88deee7ea75aafd2e37e2'] = 'Grado medio';
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_a71a0229e164fecdcde3c4e0f40473fa'] = 'Leer los comentarios de los usuarios';
$_MODULE['<{productcomments}biosanyresp>productcomments-extra_7966126831926ad29c528b239d69f855'] = 'Escribe tu opinión';
$_MODULE['<{productcomments}biosanyresp>productcomments_4494d00c901c9e22ff3b953177205cea'] = 'No hay comentarios para manejar en este momento.';
$_MODULE['<{productcomments}biosanyresp>productcomments_4b3b9db8c9784468094acde0f8bf7071'] = 'grado';
$_MODULE['<{productcomments}biosanyresp>productcomments_b5c82723bd85856358f9a376bc613998'] = '%1$d de %2$d personas encontraron esta crítica útil.';
$_MODULE['<{productcomments}biosanyresp>productcomments_39630ad6ee79b8653ea89194cdb45bec'] = 'Fue este comentario útil para usted?';
$_MODULE['<{productcomments}biosanyresp>productcomments_a6105c0a611b41b08f1209506350279e'] = 'sí';
$_MODULE['<{productcomments}biosanyresp>productcomments_7fa3b767c460b54a2be4d49030b349c7'] = 'no';
$_MODULE['<{productcomments}biosanyresp>productcomments_28b3b1e564a00f572c5d4e21da986d49'] = 'Reportar Abuso';
$_MODULE['<{productcomments}biosanyresp>productcomments_fbe2625bf3673be380d043a4bf873f28'] = 'Sé el primero en escribir tu opinión';
$_MODULE['<{productcomments}biosanyresp>productcomments_08621d00a3a801b9159a11b8bbd69f89'] = 'No hay comentarios de clientes por ahora.';
$_MODULE['<{productcomments}biosanyresp>productcomments_7966126831926ad29c528b239d69f855'] = 'Escribe tu opinión';
$_MODULE['<{productcomments}biosanyresp>productcomments_b78a3223503896721cca1303f776159b'] = 'Título';
$_MODULE['<{productcomments}biosanyresp>productcomments_0be8406951cdfda82f00f79328cf4efc'] = 'Comentario';
$_MODULE['<{productcomments}biosanyresp>productcomments_221e705c06e231636fdbccfdd14f4d5c'] = 'Su nombre:';
$_MODULE['<{productcomments}biosanyresp>productcomments_70397c4b252a5168c5ec003931cea215'] = 'Campos obligatorios';
$_MODULE['<{productcomments}biosanyresp>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = 'Enviar';
$_MODULE['<{productcomments}biosanyresp>productcomments_ea4788705e6873b424c65e91c2846b19'] = 'Anular';
$_MODULE['<{productcomments}biosanyresp>products-comparison_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comentarios';
$_MODULE['<{productcomments}biosanyresp>products-comparison_b1897515d548a960afe49ecf66a29021'] = 'Media';
$_MODULE['<{productcomments}biosanyresp>products-comparison_bc976f6c3405523cde61f63a7cbe224b'] = 'Ver las opiniones';
$_MODULE['<{productcomments}biosanyresp>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comentarios';

