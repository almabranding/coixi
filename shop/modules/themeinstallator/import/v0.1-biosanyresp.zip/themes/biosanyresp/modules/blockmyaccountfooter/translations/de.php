<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}biosanyresp>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mein Konto';
$_MODULE['<{blockmyaccountfooter}biosanyresp>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'Meine Bestellungen';
$_MODULE['<{blockmyaccountfooter}biosanyresp>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'Meine Warenretouren';
$_MODULE['<{blockmyaccountfooter}biosanyresp>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'Meine Kredit rutscht';
$_MODULE['<{blockmyaccountfooter}biosanyresp>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Meine Adresse';
$_MODULE['<{blockmyaccountfooter}biosanyresp>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'Meine persönlichen Daten';
$_MODULE['<{blockmyaccountfooter}biosanyresp>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'Meine Gutscheine';
$_MODULE['<{blockmyaccountfooter}biosanyresp>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'Austragen';

