<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist-ajax_4a84e5921e203aede886d04fc41a414b'] = 'Remove this product from my wishlist';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist-ajax_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist-ajax_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Product detail';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist-ajax_d037160cfb1fa5520563302d3a32630a'] = 'You must create a wishlist before adding products';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist-ajax_09dc02ecbb078868a3a86dded030076d'] = 'No products';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist-extra_15b94c64c4d5a4f7172e5347a36b94fd'] = 'Add to my wishlist';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist_641254d77e7a473aa5910574f3f9453c'] = 'Wishlist';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist_4a84e5921e203aede886d04fc41a414b'] = 'Remove this product from my wishlist';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Product detail';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist_09dc02ecbb078868a3a86dded030076d'] = 'No products';
$_MODULE['<{blockwishlist}biosanyresp>blockwishlist_7ec9cceb94985909c6994e95c31c1aa8'] = 'My wishlists';


