<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksocial}biosanyresp>blocksocial_d918f99442796e88b6fe5ad32c217f76'] = 'Nous suivre';

