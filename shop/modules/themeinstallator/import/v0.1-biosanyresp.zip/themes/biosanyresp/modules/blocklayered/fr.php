<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklayered}biosanyresp>blocklayered-no-products_5c9838becf9bbce28ba90a7426daf171'] = 'Il n\'y a pas de produit.';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_c32516babc5b6c47eb8ce1bfc223253c'] = 'Catalogue';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_1262d1b9fbffb3a8e85ac9e4b449e989'] = 'Filtres actifs :';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_853ae90f0351324bd73ea615e6487517'] = ' :';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_b47b72ddf8a3fa1949a7fb6bb5dbc60c'] = 'Aucun filtre';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_75954a3c6f2ea54cb9dff249b6b5e8e6'] = 'Tranche :';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_5da618e8e4b89c66fe86e32cdafde142'] = 'De';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_01b6e20344b68835c5ed1ddedf20d531'] = 'à';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_146ffe2fd9fa5bec3b63b52543793ec7'] = 'Voir plus';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_c74ea6dbff701bfa23819583c52ebd97'] = 'Voir moins';
$_MODULE['<{blocklayered}biosanyresp>blocklayered_8524de963f07201e5c086830d370797f'] = 'Chargement...';

