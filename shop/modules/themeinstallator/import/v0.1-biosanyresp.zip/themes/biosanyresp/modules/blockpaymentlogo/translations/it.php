<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_1bd130f5640104712b3c7dec66b7b0a1'] = 'Blocco logo di pagamento';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_8e27bf58ec687eea4b244d563dcbd8ac'] = 'Aggiunge un blocco per visualizzare tutti i loghi pagamento';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_8fc87743f34723d06ebff41629d2fdb5'] = 'Logo di pagamento';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_7ccf58c950043c9fbfed668df13ce608'] = 'Le impostazioni sono aggiornate';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_d16dbbe71a327e22461456cfc5e7dfb2'] = 'Nessuna pagina CMS è disponibile';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_f1206f9fadc5ce41694f69129aecac26'] = 'Configura';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_4b3c34d991275b9fdb0facfcea561be9'] = 'Pagina CMS per link';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_01bb71b3e70e9e5057c9678a903d47ac'] = 'seleziona una pagina';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_d4dccb8ca2dac4e53c01bd9954755332'] = 'Salva impostazioni';



