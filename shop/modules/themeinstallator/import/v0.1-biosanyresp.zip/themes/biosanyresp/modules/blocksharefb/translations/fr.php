<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksharefb}biosanyresp>blocksharefb_3e0fa00ee2fba747e8419e80c1da2d72'] = 'Partager sur Facebook';

