<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcms}biosanyresp>blockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'Our stores';
$_MODULE['<{blockcms}biosanyresp>blockcms_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_MODULE['<{blockcms}biosanyresp>blockcms_d1aa22a3126f04664e0fe3f598994014'] = 'Specials';
$_MODULE['<{blockcms}biosanyresp>blockcms_9ff0635f5737513b1a6f559ac2bff745'] = 'New products';
$_MODULE['<{blockcms}biosanyresp>blockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'Top sellers';


