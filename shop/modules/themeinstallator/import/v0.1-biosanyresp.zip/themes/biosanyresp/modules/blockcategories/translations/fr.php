<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}biosanyresp>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';
$_MODULE['<{blockcategories}biosanyresp>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';

