<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{favoriteproducts}biosanyresp>favoriteproducts-account_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mein Konto';
$_MODULE['<{favoriteproducts}biosanyresp>favoriteproducts-account_a34e0796b9c15d09300f67d972379722'] = 'Meine Lieblings-Produkte';
$_MODULE['<{favoriteproducts}biosanyresp>favoriteproducts-account_e2233f8a7cec20324ed48bc32ec98a5d'] = 'Keine Lieblingsartikel.';
$_MODULE['<{favoriteproducts}biosanyresp>favoriteproducts-account_0b3db27bc15f682e92ff250ebb167d4b'] = 'Zurück zu Ihrem Konto';
$_MODULE['<{favoriteproducts}biosanyresp>favoriteproducts-extra_77b65985b439ff157c1c13d63c9dc294'] = 'Dieses Produkt zu meinen Favoriten';
$_MODULE['<{favoriteproducts}biosanyresp>favoriteproducts-extra_84934524b3493305f6faf3074258b512'] = 'Entfernen Sie dieses Produkt von meiner Favoriten';
$_MODULE['<{favoriteproducts}biosanyresp>my-account_a34e0796b9c15d09300f67d972379722'] = 'Meine Lieblings-Produkte';

