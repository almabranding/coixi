<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmanufacturer}biosanyresp>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Marques';
$_MODULE['<{blockmanufacturer}biosanyresp>blockmanufacturer_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus sur';
$_MODULE['<{blockmanufacturer}biosanyresp>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Toutes les marques';
$_MODULE['<{blockmanufacturer}biosanyresp>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Aucune marques';

