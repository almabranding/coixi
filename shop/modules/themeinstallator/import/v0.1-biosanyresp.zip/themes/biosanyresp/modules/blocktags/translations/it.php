<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}biosanyresp>blocktags_189f63f277cd73395561651753563065'] = 'Tag';
$_MODULE['<{blocktags}biosanyresp>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Maggiori informazioni su';
$_MODULE['<{blocktags}biosanyresp>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Nessun tag ancora specificato';

