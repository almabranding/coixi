<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklink}biosanyresp>blocklink_fc738410141e4ec0c0319a81255a1431'] = 'Blocco link';
$_MODULE['<{blocklink}biosanyresp>blocklink_baa2ae9622a47c3217d725d1537e5187'] = 'Aggiunge un blocco con ulteriori link';
$_MODULE['<{blocklink}biosanyresp>blocklink_d98d5daaf408b77b05a2eeb6ae88d6df'] = 'Sei sicuro di voler eliminare tutti i link?';
$_MODULE['<{blocklink}biosanyresp>blocklink_fe3f38c46c80813d94b6775299e59f13'] = 'Devi compilare tutti i campi';
$_MODULE['<{blocklink}biosanyresp>blocklink_9394bb34611399534ffac4f0ece96b7f'] = 'Cattivo URL';
$_MODULE['<{blocklink}biosanyresp>blocklink_3da9d5745155a430aac6d7de3b6de0c8'] = 'Il link è stato aggiunto con successo';
$_MODULE['<{blocklink}biosanyresp>blocklink_898536ebd630aa3a9844e9cd9d1ebb9b'] = 'Si è verificato un errore durante la creazione del link';
$_MODULE['<{blocklink}biosanyresp>blocklink_b18032737875f7947443c98824103a1f'] = 'Il campo \"titolo\" non può essere vuoto';
$_MODULE['<{blocklink}biosanyresp>blocklink_43b38b9a2fe65059bed320bd284047e3'] = 'Il campo \'titolo\' non è valido';
$_MODULE['<{blocklink}biosanyresp>blocklink_eb74914f2759760be5c0a48f699f8541'] = 'Si è verificato un errore durante l\'aggiornamento del titolo';
$_MODULE['<{blocklink}biosanyresp>blocklink_5c0f7e2db8843204f422a369f2030b37'] = 'Il titolo del blocco è stato aggiornato con successo';
$_MODULE['<{blocklink}biosanyresp>blocklink_5d73d4c0bcb035a1405e066eb0cdf832'] = 'Si è verificato un errore durante la cancellazione link';
$_MODULE['<{blocklink}biosanyresp>blocklink_9bbcafcc85be214aaff76dffb8b72ce9'] = 'Il link è stato cancellato con successo';
$_MODULE['<{blocklink}biosanyresp>blocklink_7e5748d8c44f33c9cde08ac2805e5621'] = 'Ordine di selezione aggiornato con successo';
$_MODULE['<{blocklink}biosanyresp>blocklink_46cff2568b00bc09d66844849d0b1309'] = 'Si è verificato un errore durante l\'impostazione dell\'ordine di selezione';
$_MODULE['<{blocklink}biosanyresp>blocklink_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Aggiungi un nuovo link';
$_MODULE['<{blocklink}biosanyresp>blocklink_ed2fc2838f7edb7607dd1cd19f3a82e0'] = 'Testo:';
$_MODULE['<{blocklink}biosanyresp>blocklink_3b3d06023f6353f8fd05f859b298573e'] = 'URL:';
$_MODULE['<{blocklink}biosanyresp>blocklink_1f3674ab0d54a38327e8e4a0d97788d4'] = 'Apri in una nuova finestra:';
$_MODULE['<{blocklink}biosanyresp>blocklink_f16b5952df8d25ea30b25ff95ee8fedf'] = 'Associazione negozio:';
$_MODULE['<{blocklink}biosanyresp>blocklink_7f3ee1818e42cfd668e361d89b8595fb'] = 'Aggiungi questo link';
$_MODULE['<{blocklink}biosanyresp>blocklink_b22c8f9ad7db023c548c3b8e846cb169'] = 'Titolo del blocco';
$_MODULE['<{blocklink}biosanyresp>blocklink_2c906769e7f8b03cc1fedce4e24a20c2'] = 'Titolo del blocco:';
$_MODULE['<{blocklink}biosanyresp>blocklink_67c94c1cba852f2d13eed115c938baf6'] = 'URL del blocco:';
$_MODULE['<{blocklink}biosanyresp>blocklink_06933067aafd48425d67bcb01bba5cb6'] = 'Aggiornamento';
$_MODULE['<{blocklink}biosanyresp>blocklink_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blocklink}biosanyresp>blocklink_53db43446b84dd2e9ddac626fc02ead3'] = 'Ordinare l\'elenco:';
$_MODULE['<{blocklink}biosanyresp>blocklink_d36e9f57ea37903f81d28f7a189b9649'] = 'per link più recenti';
$_MODULE['<{blocklink}biosanyresp>blocklink_6ccdff04699ffe6956a6b1465907414a'] = 'per link più vecchi';
$_MODULE['<{blocklink}biosanyresp>blocklink_387a8014f530f080bf2f3be723f8c164'] = 'Elenco link';
$_MODULE['<{blocklink}biosanyresp>blocklink_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blocklink}biosanyresp>blocklink_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Testo';
$_MODULE['<{blocklink}biosanyresp>blocklink_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklink}biosanyresp>blocklink_06df33001c1d7187fdd81ea1f5b277aa'] = 'Azioni';
$_MODULE['<{blocklink}biosanyresp>blocklink_cad0a4e92b29bcb1ff1fc4f8524cfdc2'] = 'Non ci sono ancora link';



