<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksupplier}biosanyresp>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Proveedores';
$_MODULE['<{blocksupplier}biosanyresp>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'Más sobre';
$_MODULE['<{blocksupplier}biosanyresp>blocksupplier_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'Todos los proveedores';
$_MODULE['<{blocksupplier}biosanyresp>blocksupplier_496689fbd342f80d30f1f266d060415a'] = 'No hay proveedores';

