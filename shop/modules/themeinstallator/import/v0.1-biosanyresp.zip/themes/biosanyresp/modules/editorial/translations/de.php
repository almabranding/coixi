<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{editorial}biosanyresp>editorial_a46dcd3561c3feeb53903dfc0f796a35'] = 'Startseiten-Texteditor';
$_MODULE['<{editorial}biosanyresp>editorial_48b5a6f8c5a4e81cd8eb07678a981649'] = 'Ein Texteditor-Modul für Ihre Startseite';
$_MODULE['<{editorial}biosanyresp>editorial_5db205c79efd29b0e4f52d0c1ff45d20'] = 'Speichern';
$_MODULE['<{editorial}biosanyresp>editorial_0245625ee10f9c6c0ed7f50eb1838856'] = 'Haupttitel';
$_MODULE['<{editorial}biosanyresp>editorial_4fb7f07fcf38a6401743822ade34e782'] = 'Erscheint oben auf der Startseite';
$_MODULE['<{editorial}biosanyresp>editorial_e1f46be647e598f00eeb0ab62561d695'] = 'Untertitel';
$_MODULE['<{editorial}biosanyresp>editorial_bf75f228011d1443c4ea7aca23c3cff2'] = 'Einleitungstext';
$_MODULE['<{editorial}biosanyresp>editorial_617f7661941abbf06f773fcb10031c7a'] = 'Text Ihrer Wahl, zum Beispiel erläutern Sie Ihre Mission, heben ein neues Produkt hervor oder beschreiben ein aktuelles Ereignis';
$_MODULE['<{editorial}biosanyresp>editorial_78587f196180054fcb797d40f4a86f10'] = 'Logo der Startseite';
$_MODULE['<{editorial}biosanyresp>editorial_28d74ee805e3a162047d8f917b74dcb3'] = 'Startseitenlogo-Link';
$_MODULE['<{editorial}biosanyresp>editorial_98039e8f2a0d93fc0fff503f9166f59b'] = 'Startseitenlogo Untertitel';
$_MODULE['<{editorial}biosanyresp>editorial_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{editorial}biosanyresp>editorial_2563cfff94f1447b53116f3089940125'] = 'Sie können diese Handlung nicht ausführen';
$_MODULE['<{editorial}biosanyresp>editorial_5526efd7014a00a73115bcf90883d968'] = 'Ein Fehler trat beim Hochladen des Bilds auf.';
$_MODULE['<{editorial}biosanyresp>editorial_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Einstellungen erfolgreich aktualisiert';

