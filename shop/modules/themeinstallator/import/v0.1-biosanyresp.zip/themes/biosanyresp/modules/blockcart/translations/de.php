<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcart}biosanyresp>blockcart_20351b3328c35ab617549920f5cb4939'] = 'Benutzereinstellung Nr.';
$_MODULE['<{blockcart}biosanyresp>blockcart_ed6e9a09a111035684bb23682561e12d'] = 'dieses Produkt aus meinem Warenkorb entfernen';
$_MODULE['<{blockcart}biosanyresp>blockcart_c6995d6cc084c192bc2e742f052a5c74'] = 'Kostenloser Versand';
$_MODULE['<{blockcart}biosanyresp>blockcart_e7a6ca4e744870d455a57b644f696457'] = 'Gratis!';
$_MODULE['<{blockcart}biosanyresp>blockcart_f2a6c498fb90ee345d997f888fce3b18'] = 'Löschen';
$_MODULE['<{blockcart}biosanyresp>blockcart_a85eba4c6c699122b2bb1387ea4813ad'] = 'Warenkorb';
$_MODULE['<{blockcart}biosanyresp>blockcart_86024cad1e83101d97359d7351051156'] = 'Produkte';
$_MODULE['<{blockcart}biosanyresp>blockcart_f5bf48aa40cad7891eb709fcf1fde128'] = 'Produkt';
$_MODULE['<{blockcart}biosanyresp>blockcart_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(Leer)';
$_MODULE['<{blockcart}biosanyresp>blockcart_3d9e3bae9905a12dae384918ed117a26'] = 'Customization #%d :';
$_MODULE['<{blockcart}biosanyresp>blockcart_09dc02ecbb078868a3a86dded030076d'] = 'Keine Produkte';
$_MODULE['<{blockcart}biosanyresp>blockcart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Versand';
$_MODULE['<{blockcart}biosanyresp>blockcart_ba794350deb07c0c96fe73bd12239059'] = 'Verpackung';
$_MODULE['<{blockcart}biosanyresp>blockcart_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Steuer';
$_MODULE['<{blockcart}biosanyresp>blockcart_96b0141273eabab320119c467cdcaf17'] = 'Insgesamt';
$_MODULE['<{blockcart}biosanyresp>blockcart_0d11c2b75cf03522c8d97938490466b2'] = 'Preise inkl. MwSt.';
$_MODULE['<{blockcart}biosanyresp>blockcart_41202aa6b8cf7ae885644717dab1e8b4'] = 'Preise zzgl. MwSt.';
$_MODULE['<{blockcart}biosanyresp>blockcart_377e99e7404b414341a9621f7fb3f906'] = 'KAUFEN';

