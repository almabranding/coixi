<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks-footer_e1da49db34b0bdfdddaba2ad6552f848'] = 'Sitemap';
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks-footer_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'Contact';
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks-footer_05eb51862bc90ef24d04f3f1d8be5274'] = 'Bookmark this page';
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'Contact';
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'Sitemap';
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks-header_fad9383ed4698856ed467fd49ecf4820'] = 'Bookmark';
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks_e1da49db34b0bdfdddaba2ad6552f848'] = 'Sitemap';
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'Contact';
$_MODULE['<{blockpermanentlinks}biosanyresp>blockpermanentlinks_05eb51862bc90ef24d04f3f1d8be5274'] = 'Bookmark this page';


