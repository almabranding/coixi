<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_1bd130f5640104712b3c7dec66b7b0a1'] = 'Block Zahlungslogo';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_8e27bf58ec687eea4b244d563dcbd8ac'] = 'Fügt einen Block mit allen Zahlungslogos hinzu';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_8fc87743f34723d06ebff41629d2fdb5'] = 'Zahlungslogo';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_7ccf58c950043c9fbfed668df13ce608'] = 'Die Einstellungen werden aktualisiert';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_d16dbbe71a327e22461456cfc5e7dfb2'] = 'Kein CMS Seite verfügbar';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_f1206f9fadc5ce41694f69129aecac26'] = 'Konfigurieren';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_4b3c34d991275b9fdb0facfcea561be9'] = 'CMS-Seite für Link';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_01bb71b3e70e9e5057c9678a903d47ac'] = 'wählen Sie eine Seite';
$_MODULE['<{blockpaymentlogo}biosanyresp>blockpaymentlogo_d4dccb8ca2dac4e53c01bd9954755332'] = 'Speichern Sie die Einstellungen';



