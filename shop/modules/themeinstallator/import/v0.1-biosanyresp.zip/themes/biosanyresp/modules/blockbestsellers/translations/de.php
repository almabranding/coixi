<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers-home_3cb29f0ccc5fd220a97df89dafe46290'] = 'Verkaufshits';
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers-home_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Mehr';
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers-home_4351cfebe4b61d8aa5efa1d020710005'] = 'Anzeigen';
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers-home_eae99cd6a931f3553123420b16383812'] = 'Alle Verkaufshits';
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers-home_f7be84d6809317a6eb0ff3823a936800'] = 'Momentan keine Verkaufshits';
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Verkaufshits';
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Verkaufshits';
$_MODULE['<{blockbestsellers}biosanyresp>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Momentan keine Verkaufshits';

