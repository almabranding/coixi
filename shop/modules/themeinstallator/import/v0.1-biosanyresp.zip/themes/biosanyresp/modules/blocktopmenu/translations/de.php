<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_597582c140dd691b522fe42299a24d34'] = 'Einstellungen aktualisiert';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_11ad009c1b7c0615be18fe91185c179a'] = 'Der Link ist erfolgreich hinzugefügt worden';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_fb9ddcf8de4f32e4db61221d5cebb108'] = 'Shop';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_540c8f06b80b4ec911505764eb455f4d'] = 'Alles Shops';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_9dea4016dbcc290b773ab2fae678aaa8'] = 'Artikel';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_c7da501f54544eba6787960200d9efdb'] = 'Content Management System';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_ec136b444eede3bc85639fac0dd06229'] = 'Zulieferer';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_c0bd7654d5b278e65f21cf4e9153fdb4'] = 'Hersteller';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategorien';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_068f80c7519d0528fb08e82137a72131'] = 'Produkte';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_ec211f7c20af43e742bf2570c3cb84f9'] = 'Hinzufügen';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_1063e38cb53d94d386f21227fcd84717'] = 'Löschen';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_97f08a40f22a625d0cbfe03db3349108'] = 'Produkt-ID';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_dbd7201170abec94907af0cc1680d22d'] = 'Speichern';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_b021df6aac4654c454f46c77646e745f'] = 'Label';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_4994a8ffeba4ac3140beb89e8d41f174'] = 'Sprache';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_7a115fe2bd8b94ead1550a2da953cf87'] = 'Neues Fenster';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_7dce122004969d56ae2e0245cb754d35'] = 'Bearbeiten';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_5c99ba0242e549e14a00ad361de435d1'] = 'Hinzufügen';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_004bf6c9a40003140292e97330236c53'] = 'Aktion';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_93cba07454f06a4a960172bbd6e2a435'] = 'Ja';
$_MODULE['<{blocktopmenu}biosanyresp>blocktopmenu_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nein';



