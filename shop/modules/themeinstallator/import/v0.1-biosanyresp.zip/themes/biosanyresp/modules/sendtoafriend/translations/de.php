<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sendtoafriend}biosanyresp>product_page_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'An einen Freund senden';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend-extra_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'An einen Freund senden';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend-extra_5d6103b662f41b07e10687f03aca8fdc'] = 'Empfänger:';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend-extra_bb6aa0be8236a10e6d3b315ebd5f2547'] = 'Name des Freundes';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend-extra_099bc8914b5be9e522a29e48cb3c01c4'] = 'E-Mail-Adresse des Freundes';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend-extra_70397c4b252a5168c5ec003931cea215'] = 'Pflichtfelder';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend-extra_94966d90747b97d1f0f206c98a8b1ac3'] = 'Senden';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend-extra_ea4788705e6873b424c65e91c2846b19'] = 'Abbrechen';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'An einen Freund senden';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend_20589174124c25654cac3736e737d2a3'] = 'Senden Sie diese Seite einem Freund, der an diesem Artiekl interessiert sein könnte.';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend_b31afdfa73c89b567778f15180c2dd6c'] = 'Ihre Email wurde erfolgreich versendet';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend_19d305aea0ccec77d23362111ebdb6b4'] = 'Name des Freundes:';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend_7ae8a9a7a5d8fa40d4515fc52f16bb2e'] = 'E-Mail des Freundes:';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend_2541d938b0a58946090d7abdde0d3890'] = 'senden';
$_MODULE['<{sendtoafriend}biosanyresp>sendtoafriend_68728c1897e5936032fe21ffb6b10c2e'] = 'Zurück zur Produktseite';

