<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}biosanyresp>productscategory_4aae87211f77aada2c87907121576cfe'] = 'otros productos de la misma categoría:';
$_MODULE['<{productscategory}biosanyresp>productscategory_dd1f775e443ff3b9a89270713580a51b'] = 'Anterior';
$_MODULE['<{productscategory}biosanyresp>productscategory_4351cfebe4b61d8aa5efa1d020710005'] = 'Ver';
$_MODULE['<{productscategory}biosanyresp>productscategory_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Siguiente';

