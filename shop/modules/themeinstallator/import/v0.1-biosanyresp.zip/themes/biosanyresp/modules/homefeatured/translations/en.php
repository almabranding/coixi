<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}biosanyresp>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Selection of products';
$_MODULE['<{homefeatured}biosanyresp>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'No products selected';


